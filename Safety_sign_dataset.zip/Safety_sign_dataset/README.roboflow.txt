
This dataset was exported via roboflow.ai on July 24, 2021 at 5:06 PM GMT

It includes 1248 images.
Safety-signs are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Fit (black edges))

No image augmentation techniques were applied.


